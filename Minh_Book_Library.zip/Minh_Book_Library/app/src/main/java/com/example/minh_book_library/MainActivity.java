// 1. First, let's update the MainActivity.java with an improved logout function and add a logout button

package com.example.minh_book_library;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

// MainActivity handles the UI and API request
// to fetch books from Google Books API
public class MainActivity extends AppCompatActivity {

    // Variables for networking and UI components
    private RequestQueue mRequestQueue;
    private ArrayList<BookInfo> bookInfoArrayList;
    private ProgressBar progressBar;
    private EditText searchEdt;
    private ImageButton searchBtn;
    private TextView welcomeText, savedBooksTitle;
    private RecyclerView recyclerView, savedBooksRecyclerView;
    private DatabaseHelper db;
    private boolean showingSavedBooks = true;
    private Button logoutBtn; // Add a reference to the logout button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize database helper
        db = new DatabaseHelper(this);

        // Initializing UI components
        progressBar = findViewById(R.id.progressBar);
        searchEdt = findViewById(R.id.searchEditText);
        searchBtn = findViewById(R.id.searchButton);
        welcomeText = findViewById(R.id.welcomeText);
        savedBooksTitle = findViewById(R.id.savedBooksTitle);
        recyclerView = findViewById(R.id.rv);
        savedBooksRecyclerView = findViewById(R.id.savedBooksRv);
        logoutBtn = findViewById(R.id.logoutButton); // Initialize the logout button

        // Set up RecyclerViews
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        savedBooksRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set welcome message
        String username = DatabaseHelper.getCurrentUser();
        welcomeText.setText("Welcome, " + username + "!");

        // Display saved books
        displaySavedBooks();

        // Setting click listener on the search button
        searchBtn.setOnClickListener(v -> {
            // Show progress bar while searching
            progressBar.setVisibility(View.VISIBLE);
            String query = searchEdt.getText().toString();
            if (query.isEmpty()) {
                // Error if input is empty
                searchEdt.setError("Please enter search query");
                return;
            }

            // Fetch books based on the search query
            getBooksInfo(query);
            showingSavedBooks = false;
            savedBooksTitle.setText("Search Results:");
        });

        // Set click listener for logout button
        logoutBtn.setOnClickListener(v -> {
            performLogout();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh saved books when returning to this activity
        if (showingSavedBooks) {
            displaySavedBooks();
        }
    }

    // Display saved books
    private void displaySavedBooks() {
        ArrayList<BookInfo> savedBooks = db.getSavedBooks();
        if (savedBooks.isEmpty()) {
            savedBooksTitle.setText("You haven't saved any books yet");
            savedBooksRecyclerView.setVisibility(View.GONE);
        } else {
            savedBooksTitle.setText("Your Saved Books:");
            savedBooksRecyclerView.setVisibility(View.VISIBLE);
            BookAdapter adapter = new BookAdapter(savedBooks, this);
            savedBooksRecyclerView.setAdapter(adapter);
        }
    }

    // Create menu with logout option
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    // Handle menu item selection
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_logout) {
            // Call the improved logout method
            performLogout();
            return true;
        } else if (id == R.id.menu_show_saved) {
            // Switch to saved books view
            showingSavedBooks = true;
            recyclerView.setVisibility(View.GONE);
            savedBooksRecyclerView.setVisibility(View.VISIBLE);
            displaySavedBooks();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Improved logout function
    private void performLogout() {
        // Show confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Đăng xuất");
        builder.setMessage("Bạn có chắc chắn muốn đăng xuất?");

        // Add the buttons
        builder.setPositiveButton("Có", (dialog, which) -> {
            // Clear user data
            DatabaseHelper.setCurrentUser("");

            // Clear search results
            if (bookInfoArrayList != null) {
                bookInfoArrayList.clear();
            }

            // Cancel any pending network requests
            if (mRequestQueue != null) {
                mRequestQueue.cancelAll(request -> true);
            }

            // Show toast message
            Toast.makeText(MainActivity.this, "Đăng xuất thành công", Toast.LENGTH_SHORT).show();

            // Navigate to login screen
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        builder.setNegativeButton("Không", (dialog, which) -> {
            // User clicked No, so just dismiss the dialog
            dialog.dismiss();
        });

        // Create and show the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Function to fetch book data from Google Books API
    private void getBooksInfo(String query) {
        // Initialize the book list
        bookInfoArrayList = new ArrayList<>();
        mRequestQueue = Volley.newRequestQueue(this);

        // Clear cache before making a new request
        mRequestQueue.getCache().clear();

        // Construct API URL using the search query
        String url = "https://www.googleapis.com/books/v1/volumes?q=" + query;
        RequestQueue queue = Volley.newRequestQueue(this);

        // Make API request to get book data
        JsonObjectRequest booksObjRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    // Hide progress bar after fetching data
                    progressBar.setVisibility(View.GONE);
                    try {
                        // Get book items array
                        JSONArray itemsArray = response.getJSONArray("items");

                        for (int i = 0; i < itemsArray.length(); i++) {
                            JSONObject itemsObj = itemsArray.getJSONObject(i);
                            JSONObject volumeObj = itemsObj.getJSONObject("volumeInfo");

                            // Extract book details with default values
                            String title = volumeObj.optString("title", "N/A");
                            String subtitle = volumeObj.optString("subtitle", "N/A");
                            JSONArray authorsArray = volumeObj.optJSONArray("authors");
                            String publisher = volumeObj.optString("publisher", "N/A");
                            String publishedDate = volumeObj.optString("publishedDate", "N/A");
                            String description = volumeObj.optString("description", "N/A");
                            int pageCount = volumeObj.optInt("pageCount", 0);

                            // Get book thumbnail if available
                            JSONObject imageLinks = volumeObj.optJSONObject("imageLinks");
                            String thumbnail = (imageLinks != null) ? imageLinks.optString("thumbnail", "") : "";

                            // Get book preview and info links
                            String previewLink = volumeObj.optString("previewLink", "");
                            String infoLink = volumeObj.optString("infoLink", "");

                            // Convert authors JSONArray to ArrayList<String>
                            ArrayList<String> authorsArrayList = new ArrayList<>();
                            if (authorsArray != null) {
                                for (int j = 0; j < authorsArray.length(); j++) {
                                    authorsArrayList.add(authorsArray.optString(j, "Unknown"));
                                }
                            }

                            // Create BookInfo object with fetched details
                            BookInfo bookInfo = new BookInfo(
                                    title, subtitle, authorsArrayList, publisher, publishedDate,
                                    description, pageCount, thumbnail, previewLink, infoLink, ""
                            );

                            // Add book details to the list
                            bookInfoArrayList.add(bookInfo);
                        }

                        // Show search results
                        savedBooksRecyclerView.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);

                        // Set up RecyclerView with BookAdapter to display the book list
                        BookAdapter adapter = new BookAdapter(bookInfoArrayList, this);
                        recyclerView.setAdapter(adapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "No Data Found: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    // Hide progress bar after error
                    progressBar.setVisibility(View.GONE);
                    // Handle API request error
                    Toast.makeText(this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                });

        // Add request to the Volley queue
        queue.add(booksObjRequest);
    }
}